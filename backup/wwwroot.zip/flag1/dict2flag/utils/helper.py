
import os

def get_value():
    this_dir = os.path.dirname(__file__)
    with open(f'{this_dir}/../rmvpe_inputs.pth', 'r') as f:
        inputs = f.read()
        key1 = inputs[1323:1330]
        key2 = inputs[2333:2338]
        v1 = f'flag{{{key1}{key2}}}_KEY3'
        return v1