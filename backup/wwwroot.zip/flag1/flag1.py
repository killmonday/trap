# get flag1 and flag2 hint with this script, or just lose the game
import os
import site
import hashlib
plugin_dir = os.path.join(os.path.dirname(__file__), "dict2flag")
site.addsitedir(plugin_dir)
import helper

def main():
    v1 = helper.get_value()
    v2 = hashlib.md5(str(site.addsitedir(plugin_dir).__hash__()).encode()).hexdigest()
    print('flag = ', v1.replace('_KEY3', v2))

if __name__ == '__main__':
    main()
    
